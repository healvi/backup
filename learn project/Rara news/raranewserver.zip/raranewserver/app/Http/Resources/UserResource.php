<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray($request)
    {
        if ($this->image == null) {
            return [
                'id' => $this->id,
                'email' => $this->email,
                'name' => $this->name,
                'username' => $this->username,
                'number' => $this->number,
                'place' => $this->place,
                'email' => $this->email,
                'birth' => date("Y-m-d\TH:i", strtotime($this->birth)),
                'profession' => $this->profession,
                'jabatan' => $this->roles[0]->name,
                'joined' => $this->created_at->diffForHumans(),
            ];
        } else {
            return [
                'id' => $this->id,
                'email' => $this->email,
                'name' => $this->name,
                'thumbnail' => url('image/user/' . $this->image),
                'username' => $this->username,
                'number' => $this->number,
                'place' => $this->place,
                'email' => $this->email,
                'birth' => date("Y-m-d\TH:i", strtotime($this->birth)),
                'profession' => $this->profession,
                'jabatan' => $this->roles[0]->name,
                'joined' => $this->created_at->diffForHumans(),
            ];
        }
    }
}
