<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;

class NewsCollection extends JsonResource
{

    public function toArray($request)
    {
        if ($this->image == null) {
            return [
                'writer' => $this->user->name,
                'title' => $this->title,
                'slug' => $this->slug,
                'body' => $this->body,
                'pembuatan' => date("d M Y H:i:s", strtotime($this->created_at)),
                'publikasi' => date("d M Y H:i:s", strtotime($this->update_at)),
                'kategory' => $this->kategory[0]->title
            ];
        } else {
            return [
                'image' => url('image/artikel/' . $this->image),
                'writer' => $this->user->name,
                'title' => $this->title,
                'slug' => $this->slug,
                'body' => $this->body,
                'pembuatan' => date("d M Y H:i:s", strtotime($this->created_at)),
                'publikasi' => date("d M Y H:i:s", strtotime($this->update_at)),
                'kategory' => $this->kategory[0]->title
            ];
        }
    }
}
