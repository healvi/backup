<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class KategoryCollection extends ResourceCollection
{

    public function toArray($request)
    {
        return [
            'data' => collect($this->collection)->map(function ($kategory) {
                return [
                    'kategory' . $kategory->title => $kategory->title,
                    $kategory->title  => new newskatCollection($kategory->artikel()->latest()->paginate("4"))
                ];
            }),
        ];
    }
}
