<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class randomkatCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => collect($this->collection)->map(function ($artikel) {
                if ($artikel->image == null) {
                    return [
                        'writer' => $artikel->user->name,
                        'title' => $artikel->title,
                        'slug' => $artikel->slug,
                        'body' => $artikel->body,
                        'pembuatan' => date("d M Y H:i:s", strtotime($artikel->created_at)),
                        'publikasi' => date("d M Y H:i:s", strtotime($artikel->update_at)),
                        'kategory' => $artikel->kategory[0]->title,
                    ];
                } else {
                    return [
                        'writer' => $artikel->user->name,
                        'image' => url('image/artikel/' . $artikel->image),
                        'title' => $artikel->title,
                        'slug' => $artikel->slug,
                        'body' => $artikel->body,
                        'pembuatan' => date("d M Y H:i:s", strtotime($artikel->created_at)),
                        'publikasi' => date("d M Y H:i:s", strtotime($artikel->update_at)),
                        'kategory' => $artikel->kategory[0]->title,
                    ];
                }
            }),
        ];
    }
}
