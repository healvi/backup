<?php

namespace App\Http\Resources;

use App\Models\role;
use Illuminate\Http\Resources\Json\ResourceCollection;

class UserCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => collect($this->collection)->map(function ($user) {
                if ($user->image == null) {
                    return [
                        'name' => $user->name,
                        'username' => $user->username,
                        'number' => $user->number,
                        'place' => $user->place,
                        'email' => $user->email,
                        // yyyy-MM-dd hh:mm
                        'birth' => date("Y-M-d H:i", strtotime($user->birth)),
                        'profession' => $user->profession,
                        'jabatan' => $user->roles[0]->name,
                        'roles' => role::get("name")
                    ];
                } else {
                    return [
                        'thumbnail' => url('image/user/' . $user->image),
                        'name' => $user->name,
                        'username' => $user->username,
                        'number' => $user->number,
                        'place' => $user->place,
                        'email' => $user->email,
                        'birth' => date("Y-M-d H:i", strtotime($user->birth)),
                        'profession' => $user->profession,
                        'jabatan' => $user->roles[0]->name,
                        'roles' => role::get("name")
                    ];
                }
            }),
        ];
    }
}
