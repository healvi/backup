<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class newskatCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => collect($this->collection)->map(function ($artikel) {
                if ($artikel->image == null) {
                    return [
                        'writer' => $artikel->user->name,
                        'title' => $artikel->title,
                        'slug' => $artikel->slug,
                        'body' => $artikel->body,
                        'pembuatan' => date("d M Y H:i:s", strtotime($artikel->created_at)),
                        'publikasi' => date("d M Y H:i:s", strtotime($artikel->update_at)),
                        'kategory' => $artikel->kategory[0]->title,
                    ];
                } else {
                    return [
                        'writer' => $artikel->user->name,
                        'image' => url('image/artikel/' . $artikel->image),
                        'title' => $artikel->title,
                        'slug' => $artikel->slug,
                        'body' => $artikel->body,
                        'pembuatan' => date("d M Y H:i:s", strtotime($artikel->created_at)),
                        'publikasi' => date("d M Y H:i:s", strtotime($artikel->update_at)),
                        'kategory' => $artikel->kategory[0]->title,
                    ];
                }
            }),
            'meta'  => [
                'current_page' => $this->currentPage(),
                'first_page_url' => $this->url(1),
                'from' => $this->firstItem(),
                'last_page' => $this->lastPage(),
                'last_page_url' => $this->url($this->lastPage()),
                'next_page_url' => $this->nextPageUrl(),
                'path' => $this->path(),
                'per_page' => $this->perPage(),
                'links' => $this->linkCollection()->toArray(),
                'prev_page_url' => $this->previousPageUrl(),
                'to' => $this->lastItem(),
                'total' => $this->total(),
            ]
        ];
    }
}
