<?php

namespace App\Http\Controllers;

use App\Http\Requests\ArtikelRequest;
use App\Http\Requests\ImageRequest;
use App\Http\Resources\ArtikelCollection;
use App\Http\Resources\KategoryCollection;
use App\Http\Resources\NewsCollection;
use App\Http\Resources\newskatCollection;
use App\Http\Resources\randomkatCollection;
use App\Models\content\artikel;
use App\Models\content\kategory;
use App\Models\content\publication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ArtikelController extends Controller
{

    public function news()
    {
        $artikel = kategory::latest()->with('artikel')->get();
        return response()->json([new KategoryCollection($artikel)]);
    }

    public function newsByKategory(kategory $kategory)
    {
        $artikel = $kategory->artikel()->latest()->paginate("4");
        return response()->json([new newskatCollection($artikel)]);
    }

    public function newsBySlug(artikel $artikel)
    {
        return response()->json([new NewsCollection($artikel)]);
    }

    public function randoms($count)
    {
        $artikel = artikel::all()->random($count);
        return response()->json([new randomkatCollection($artikel)]);
    }

    public function index()
    {
        $user = Auth::user();
        $artikel = $user->artikels()->latest()->with('kategory')->paginate("25");
        return response()->json([new ArtikelCollection($artikel), 'kategory' => kategory::get("title")]);
    }

    public function kategory()
    {
        $user = Auth::user();
        if ($user) {
            return response(kategory::get("title"));
        }
    }

    public function store(Request $request)
    {

        $attr = $request->all();
        $attr = ArtikelRequest::created($attr);
        ArtikelRequest::rulesi($attr);

        $url = 'app/public/image/artikel/';
        if (request("image")) {
            $attr["image"] = ImageRequest::convert($attr, $url);
            if ($attr["image"] == "salah") {
                unset($attr["image"]);
            }
        }

        $hibrainers = auth()->user()->artikels()->create($attr);
        $hibrainers->kategory()->attach($attr['kategory']);
        $hibrainers->publication()->attach("2");
        return response("succeess");
    }


    public function update(Request $request, artikel $artikel)
    {
        $attr = $request->all();
        $attr = ArtikelRequest::update($attr);
        ArtikelRequest::rulesi($attr);

        $url = 'app/public/image/artikel/';
        if (request("image")) {
            if ($artikel->image == null) {
                $attr["image"] = ImageRequest::convert($attr, $url);
            } else {
                $attr["image"] = ImageRequest::convert($attr, $url);
                Storage::delete("image/artikel/" . $artikel->image);
            }
        } else {
            $attr["image"] = $artikel->image;
        }
        if ($attr["image"] == "salah") {
            unset($attr["image"]);
        }

        $artikel->update($attr);
        $artikel->kategory()->sync($attr['kategory']);
        return response("succeess");
    }

    public function destroy(artikel $artikel)
    {
        if ($artikel->image != null) {
            Storage::delete("image/artikel/" . $artikel->image);
        }
        $artikel->publication()->detach();
        $artikel->kategory()->detach();
        $artikel->delete();
        return response()->json(['success' => "the post deleted"]);
    }


    // Admin
    public function indexAdmin()
    {
        $artikel = artikel::latest()->with('kategory')->paginate("25");
        return response()->json([new ArtikelCollection($artikel), 'kategory' => kategory::get("title"), 'status' => publication::get("title")]);
    }
    public function updateadmin(Request $request, artikel $artikel)
    {
        $attr = $request->all();
        $attr = ArtikelRequest::updateadmin($attr);
        ArtikelRequest::rulesi($attr);

        $url = 'app/public/image/artikel/';
        if (request("image")) {
            if ($artikel->image == null) {
                $attr["image"] = ImageRequest::convert($attr, $url);
            } else {
                $attr["image"] = ImageRequest::convert($attr, $url);
                Storage::delete("image/artikel/" . $artikel->image);
            }
        } else {
            $attr["image"] = $artikel->image;
        }
        if ($attr["image"] == "salah") {
            unset($attr["image"]);
        }

        $artikel->update($attr);
        $artikel->kategory()->sync($attr['kategory']);
        $artikel->publication()->sync($attr['status']);
        return response("succeess");
    }
}
