<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function Login()
    {
        request()->validate([
            'email' => 'required',
            'password' => 'required'
        ]);
        $auth = Auth::attempt(request()->only('email', 'password'));
        if ($auth) {
            return response($auth);
        } else {
            abort(403, 'Unauthorized.');
        }
        // try {
        //     request()->validate([
        //         'email' => 'required',
        //         'password' => 'required'
        //     ]);

        //     $user = User::where('email', request()->email)->first();
        //     if (!Hash::check(request()->password, $user->password, [])) {
        //         return response()->json(["error" => "Anda salah password"], 403);
        //     }
        //     $role = $user->roles()->get();
        //     $tokenResult = $user->createToken('token-name', [$role[0]->name])->plainTextToken;
        //     return response()->json(['token' => $tokenResult], 200);
        // } catch (Exception $error) {
        //     return response()->json(["error" => "Anda gagal Login"], 500);
        // }
    }
}
