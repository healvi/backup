<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;

class ForgotPasswordController extends Controller
{
    // // use SendsPasswordResetEmails;
    // public function showResetForm(Request $request) {
    //   return view('auth.passwords.email');
    // }

    public function email(Request $request)
    {
        return redirect()->away('http://localhost:3000/auth/reset/' . $request->token)->withInput(['token' => $request->token]);
    }

    public function reset(Request $request)
    {

        $request->validate(['email' => 'required|email']);

        $status = Password::sendResetLink(
            $request->only('email')
        );
        return $status === Password::RESET_LINK_SENT
            ? response()
            ->json(['succeess' => 'open email for change your password'])
            : response()
            ->json(['errors' => 'failed your email not avaliable']);
    }
}
