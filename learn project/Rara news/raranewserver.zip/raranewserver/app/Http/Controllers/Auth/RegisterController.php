<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function register()
    {
        $attributes = request()->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'min:8|required',
        ]);

        $attributes['password'] = bcrypt(request('password'));
        $auth = User::create([
            'name' => $attributes['name'],
            'email' => $attributes['email'],
            'password' => $attributes['password'],

        ]);
        $auth->sendEmailVerificationNotification();
        $auth->roles()->attach("3");
        return response("succeess");
    }
}
