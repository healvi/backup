<?php

namespace App\Http\Controllers;

use App\Http\Requests\ImageRequest;
use App\Http\Requests\UserRequest;
use App\Http\Resources\UserCollection;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    public function index()
    {
        $user = User::latest()->with('roles')->paginate("25");
        return new UserCollection($user);
    }
    public function store(Request $request)
    {
        $attr = $request->all();
        $url = 'app/public/image/user/';
        $attr = UserRequest::update($attr);
        UserRequest::rules($attr);
        if (request("image")) {
            $attr["image"] = ImageRequest::convert($attr, $url);
            if ($attr["image"] == "salah") {
                unset($attr["image"]);
            }
        }
        $hibrainers = User::create($attr);
        $hibrainers->sendEmailVerificationNotification();
        $hibrainers->roles()->attach($attr['role']);
        return response("succeess");
    }
    public function update(User $user)
    {
        $url = 'app/public/image/user/';
        $attr = UserRequest::update(request()->all());
        // return response()->json(['success' => $attr]);
        UserRequest::rules($attr);
        if (request("image")) {
            if ($user->image == null) {
                $attr["image"] = ImageRequest::convert($attr, $url);
            } else {
                $attr["image"] = ImageRequest::convert($attr, $url);
                Storage::delete($user->image);
            }
        } else {
            $attr["image"] = $user->image;
        }

        if ($attr["image"] == "salah") {
            unset($attr["image"]);
        }
        if ($user->email != request('email')) {
            $attr['email_verified_at'] = null;
            $user->update($attr);
            $user->sendEmailVerificationNotification();
        } else {
            $user->update($attr);
        }

        $user->roles()->sync($attr['role']);
        return response()->json(['success' => $attr]);
    }

    public function destroy(User $user)
    {
        if ($user->image != null) {
            Storage::delete($user->image);
        }
        $user->roles()->detach();
        $user->delete();
        return response()->json(['success' => "the post deleted"]);
    }
}
