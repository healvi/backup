<?php

namespace App\Http\Controllers;

use App\Http\Requests\ImageRequest;
use App\Http\Requests\UserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class MeController extends Controller
{
    public function me(Request $request)
    {
        return new UserResource($request->user());
    }

    public function updateprofile(Request $request, User $user)
    {
        $user = User::where('username', Auth::user()->username)->firstorfail();
        $attr = $request->all();
        $url = 'app/public/image/user/';
        $urls = 'image/user/';
        $attr = UserRequest::update($attr);
        UserRequest::rules($attr);
        if (request("image")) {
            if ($user->image == null) {
                $attr["image"] = ImageRequest::convert($attr, $url);
            } else {
                $attr["image"] = ImageRequest::convert($attr, $url);
                Storage::delete($urls . $user->image);
            }
        } else {
            $attr["image"] = $user->image;
        }
        // Update
        if ($attr["image"] == "salah") {
            unset($attr["image"]);
        }
        if ($user->email != request('email')) {
            $attr['email_verified_at'] = null;
            $user->update($attr);
            $user->sendEmailVerificationNotification();
        } else {
            $user->update($attr);
        }
        unset($attr['role']);
        return response()->json(['success' => $attr]);
    }
}
