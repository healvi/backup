<?php

namespace App\Http\Requests;

use App\Models\content\kategory;
use App\Models\content\publication;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Validator;

class ArtikelRequest extends FormRequest
{
    public function authorize()
    {
        return false;
    }

    public static function created($attr)
    {
        if (strlen($attr["title"]) < 15) {
            $attr["slug"] = \Str::slug($attr["title"]);
        } else {
            $attr["slug"] = \Str::slug(substr($attr["title"], 0, 25));
        }
        $nametitle = $attr["kategory"]["title"];
        $attr["kategory"] = kategory::where('title', '=', $nametitle)->firstOrFail();
        $attr["kategory"] = $attr["kategory"]["id"];
        $attr["title"] = strtolower($attr["title"]);
        return $attr;
    }

    public static function update($attr)
    {
        $attr["kategory"] = kategory::where('title', '=', $attr["kategory"])->firstOrFail();
        $attr["kategory"] = $attr["kategory"]["id"];
        $attr["title"] = strtolower($attr["title"]);
        return $attr;
    }

    public static function updateadmin($attr)
    {
        $attr["kategory"] = kategory::where('title', '=', $attr["kategory"])->firstOrFail();
        $attr["kategory"] = $attr["kategory"]["id"];

        $attr["status"] = publication::where('title', '=', $attr["status"])->firstOrFail();
        $attr["status"] = $attr["status"]["id"];

        $attr["title"] = strtolower($attr["title"]);
        return $attr;
    }


    public static function rulesi($attr)
    {
        $messages = [
            'title.required' => 'Tidak boleh kosong harus min 3 huruf',
            'body.required' => 'Maaf isi artikel harus Ada',
        ];

        $validator =  Validator::make($attr, [
            'title' => 'required|min:3',
            'body' => 'required',
        ], $messages)->validate();

        return $validator;
    }
}
