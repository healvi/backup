<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ImageRequest extends FormRequest
{
    public function authorize()
    {
        return false;
    }


    public static function convert($attr, $url)
    {
        $image = $attr['image'];
        if (!strpos($image, "/image")) {
            if (!isset($image) || $image == null) {
                return "salah mid dalam";
            } else {
                $name = time() . '.' . explode('/', explode(':', substr($attr["image"], 0, strpos($attr["image"], ';')))[1])[1];
                $ex = explode('/', explode(':', substr($attr["image"], 0, strpos($attr["image"], ';')))[1])[1];
                if ($ex == 'jpeg' || $ex == 'jpg' || $ex == 'png') {
                    $image = \Image::make($attr["image"]);
                    $imgSave = $image->save(storage_path($url) . $name);
                    return $name;
                } else {
                    return "salah dalam";
                }
            }
        } else {
            return "salah";
        }
    }
}
