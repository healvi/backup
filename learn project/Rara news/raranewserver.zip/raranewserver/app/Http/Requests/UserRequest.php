<?php

namespace App\Http\Requests;

use App\Models\role;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserRequest extends FormRequest
{
    public function authorize()
    {
        return false;
    }
    public static function update($attr)
    {
        $attr["role"] = $attr["jabatan"];
        if ($attr["role"] == null) {
            $attr["role"] = "3";
        } else {
            $attr["role"] = role::where('name', '=', $attr["jabatan"])->firstOrFail();
            $attr["role"] = $attr["role"]["id"];
        }

        if (strlen($attr["name"]) < 10) {
            $attr["username"] = \Str::slug($attr["name"]);
        } else {
            $attr["username"] = \Str::slug(substr($attr["name"], 0, 10));
        }

        unset($attr["jabatan"]);
        $attr["username"] = strtolower($attr['username']);
        $attr["birth"] =  date("Y-m-d H:i:s", strtotime($attr['birth']));
        if (isset($attr['password'])) {
            $attr['password'] = Hash::make($attr['password']);
        }
        return $attr;
    }

    public static function rules($attr)
    {
        $messages = [
            'email.required' => 'Tidak boleh kosong',
            'number.required' => 'Tidak boleh kosong',
            'password.min' => 'Isi minimal 8 kharakter',
            'email.email' => 'andala memasukan email yang salah',
        ];

        $validator =  Validator::make($attr, [
            'email' => 'required|email',
            'password' => 'sometimes|min:8',
            'number' => 'required',
            'username' => 'required|regex:/^\S*$/u',
        ], $messages)->validate();

        return $validator;
    }
}
