<?php

namespace App\Models\content;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class publication extends Model
{
    use HasFactory;
    protected $fillable = [
        'title',
    ];
    public function artikels()
    {
        return $this->belongsToMany(artikel::class);
    }
}
