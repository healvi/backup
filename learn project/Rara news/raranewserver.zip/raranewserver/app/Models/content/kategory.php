<?php

namespace App\Models\content;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class kategory extends Model
{
    use HasFactory;
    protected $fillable = [
        'title',
        'slug',
    ];
    public function artikel()
    {
        return $this->belongsToMany(artikel::class);
    }
}
