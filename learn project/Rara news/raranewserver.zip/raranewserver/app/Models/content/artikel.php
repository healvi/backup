<?php

namespace App\Models\content;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class artikel extends Model
{
    use HasFactory;
    protected $fillable = [
        'title',
        'slug',
        'body',
        'image',
        'user_id'
    ];
    public function publication()
    {
        return $this->belongsToMany(publication::class);
    }
    public function kategory()
    {
        return $this->belongsToMany(kategory::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
