<?php

namespace Database\Factories\content;

use App\Models\content\publication;
use Illuminate\Database\Eloquent\Factories\Factory;

class publicationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = publication::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
