<?php

namespace Database\Factories\content;

use App\Models\content\kategory;
use Illuminate\Database\Eloquent\Factories\Factory;

class kategoryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = kategory::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
