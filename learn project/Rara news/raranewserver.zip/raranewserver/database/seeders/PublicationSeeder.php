<?php

namespace Database\Seeders;

use App\Models\content\publication;
use Illuminate\Database\Seeder;

class PublicationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $publikasi = collect(['publikasi', 'pending', 'ditolak']);
        $publikasi->each(function ($c) {
            publication::create([
                'title' => $c,
            ]);
        });
    }
}
