<?php

namespace Database\Seeders;

use App\Models\content\kategory;
use Illuminate\Database\Seeder;

class KategorySeeder extends Seeder
{
    public function run()
    {
        $publikasi = collect(['bahasa', 'budaya', 'sastra', 'tokoh', 'news']);
        $publikasi->each(function ($c) {
            kategory::create([
                'title' => $c,
                'slug' => \Str::slug($c),
            ]);
        });
    }
}
