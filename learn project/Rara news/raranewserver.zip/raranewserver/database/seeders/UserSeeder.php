<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => "mohammad irvan",
            'username' => "healvi",
            'email' => "healvimaginer@gmail.com",
            'number' => "085735784029",
            'password' => bcrypt("9ori=Tal8")
        ]);
    }
}
