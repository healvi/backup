<?php

namespace Database\Seeders;

use App\Models\role;
use Illuminate\Database\Seeder;

class roleseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role = collect(['admin', 'writer', 'member']);
        $role->each(function ($c) {
            role::create([
                'name' => $c,
            ]);
        });
    }
}
