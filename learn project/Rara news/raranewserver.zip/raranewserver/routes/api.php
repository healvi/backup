<?php

use App\Http\Controllers\ArtikelController;
use App\Http\Controllers\MeController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routfirses for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('news', [ArtikelController::class, 'news']);
Route::get('random/artikel/{count}', [ArtikelController::class, 'randoms']);
Route::get('{kategory:slug}/news', [ArtikelController::class, 'newsByKategory']);
Route::get('{artikel:slug}/artikel', [ArtikelController::class, 'newsBySlug']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('me', [MeController::class, 'me']);
    Route::get('artikel', [ArtikelController::class, 'index']);
    Route::get('artikel/kategory', [ArtikelController::class, 'kategory']);
    Route::post('artikel/store', [ArtikelController::class, 'store']);
    Route::put('{artikel:slug}/update', [ArtikelController::class, 'update']);
    Route::delete('{artikel:slug}/delete', [ArtikelController::class, 'destroy']);

    Route::prefix('leaderadmin')->group(function () {
        Route::get('artikeladmin', [ArtikelController::class, 'indexAdmin']);
        Route::put('{artikel:slug}/update', [ArtikelController::class, 'updateadmin']);
        Route::get('user', [UserController::class, 'index']);
        Route::post('createuser', [UserController::class, 'store']);
        Route::put('{user:username}/userupdate', [UserController::class, 'update']);
        Route::delete('{user:username}/userdelete', [UserController::class, 'destroy']);
    });
});
