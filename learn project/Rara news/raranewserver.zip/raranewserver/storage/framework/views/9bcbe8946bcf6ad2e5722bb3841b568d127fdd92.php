<?php echo e($slot); ?>

<?php /**PATH C:\Users\healvi maginer\Documents\project\Rara news\raranewserver\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>